function login() {
    //alert("Login Berhasil");
    let uname = document.getElementById("username");
    let pass = document.getElementById("password");

    console.log("Username : " + uname.value);
    console.log("Password : " + pass.value);
    if(uname.value=="admin" && pass.value=="admin") {
        alert("Selamat Datang");
        window.location.href = "admin.html"
    }else{
        alert("Username atau Password Salah");
    }
}